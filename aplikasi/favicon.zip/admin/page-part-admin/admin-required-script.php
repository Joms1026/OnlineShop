<!-- jQuery -->
<script src="vendor-admin/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="vendor-admin/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- overlayScrollbars -->
<script src="vendor-admin/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="vendor-admin/dist/js/adminlte.js"></script>