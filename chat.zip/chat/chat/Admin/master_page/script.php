<!-- BEGIN VENDOR JS-->
<script src="robust-assets/js/vendors.min.js"></script>
<!-- BEGIN VENDOR JS-->
<!-- BEGIN PAGE VENDOR JS-->
<script src="robust-assets/js/plugins/extensions/jquery.knob.min.js" type="text/javascript"></script>
<script src="robust-assets/js/plugins/charts/raphael-min.js" type="text/javascript"></script>
<script src="robust-assets/js/plugins/charts/morris.min.js" type="text/javascript"></script>
<script src="robust-assets/js/plugins/charts/chartist.min.js" type="text/javascript"></script>
<script src="robust-assets/js/plugins/charts/chartist-plugin-tooltip.js" type="text/javascript"></script>
<script src="robust-assets/js/plugins/charts/chart.min.js" type="text/javascript"></script>
<script src="robust-assets/js/plugins/charts/jquery.sparkline.min.js" type="text/javascript"></script>
<script src="robust-assets/js/plugins/charts/jvector/jquery-jvectormap-2.0.3.min.js" type="text/javascript"></script>
<script src="robust-assets/js/plugins/charts/jvector/jquery-jvectormap-world-mill.js" type="text/javascript"></script>
<script src="robust-assets/js/plugins/extensions/moment.min.js" type="text/javascript"></script>
<script src="robust-assets/js/plugins/extensions/underscore-min.js" type="text/javascript"></script>
<script src="robust-assets/js/plugins/extensions/clndr.min.js" type="text/javascript"></script>
<script src="robust-assets/js/plugins/extensions/unslider-min.js" type="text/javascript"></script>
<!-- END PAGE VENDOR JS-->
<!-- BEGIN ROBUST JS-->
<script src="robust-assets/js/app.min.js"></script>
<!-- END ROBUST JS-->
<!-- BEGIN PAGE LEVEL JS-->
<script src="robust-assets/js/components/pages/dashboard-project.js" type="text/javascript"></script>



<script src="js/javascript.js" type="text/javascript"></script>
<!-- END PAGE LEVEL JS-->




<!-- start Data Table facility  -->
<!--
    <script src="robust-assets/js/plugins/tables/jquery.dataTables.min.js" type="text/javascript"></script>
    <script src="robust-assets/js/plugins/tables/datatable/dataTables.bootstrap4.min.js" type="text/javascript"></script>
    <script src="robust-assets/js/components/tables/datatables/datatable-basic.js" type="text/javascript"></script>
   -->
<!-- end Data Table facility  -->




<!-- start Data Table facility  -->

    <!-- BEGIN PAGE VENDOR JS-->
    <script src="robust-assets/js/plugins/tables/jquery.dataTables.min.js" type="text/javascript"></script>
   
    
    <script src="robust-assets/js/plugins/tables/datatable/dataTables.bootstrap4.min.js" type="text/javascript"></script>
    
    
    <script src="robust-assets/js/plugins/tables/datatable/dataTables.buttons.min.js" type="text/javascript"></script>
    
    <script src="robust-assets/js/plugins/tables/buttons.flash.min.js" type="text/javascript"></script>
    <script src="robust-assets/js/plugins/tables/buttons.print.min.js" type="text/javascript"></script>
    <!-- END PAGE VENDOR JS-->
    <!-- BEGIN PAGE LEVEL JS-->
    <script src="robust-assets/js/components/tables/datatables/datatable-advanced.js" type="text/javascript"></script>
    <!-- END PAGE LEVEL JS-->
    <script type="text/javascript" src="js/chat.js"></script>
<!-- end Data Table facility  -->